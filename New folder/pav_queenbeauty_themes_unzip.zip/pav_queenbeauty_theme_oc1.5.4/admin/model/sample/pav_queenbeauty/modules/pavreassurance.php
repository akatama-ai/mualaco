a:1:{i:0;a:6:{s:6:"prefix";s:0:"";s:9:"layout_id";s:1:"1";s:8:"position";s:14:"content_bottom";s:6:"status";s:1:"1";s:10:"sort_order";i:1;s:15:"pavreassurances";a:3:{i:1;a:4:{s:11:"select_icon";s:8:"fa-truck";s:5:"title";a:2:{i:1;s:27:"FREE SHIPPING ON ALL ORDERS";i:2;s:52:"الحرة الشحن على جميع الأوامر";}s:7:"caption";a:2:{i:1;s:166:"&lt;p&gt;Get Free Shipping on all orders over $75 and free returns to our UK returns centre! Items are dispatched from the US and will arrive in 5-8 days.&lt;/p&gt;
";i:2;s:1148:"&lt;p&gt;&lt;span id=&quot;result_box&quot; lang=&quot;ar&quot;&gt;&lt;span class=&quot;hps&quot;&gt;احصل على شحن&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;مجاني على جميع&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;أوامر&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;أكثر من دولار&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;75 و&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;عوائد&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;حرة في&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;المملكة المتحدة&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;لدينا&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;مركز العودة&lt;/span&gt;&lt;span&gt;!&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;وارسلت وحدات&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;من الولايات المتحدة&lt;/span&gt;&lt;span&gt;، وسوف&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;تصل&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;في 5-8&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;أيام&lt;/span&gt;&lt;span&gt;.&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;
";}s:6:"detail";a:2:{i:1;s:1504:"&lt;div class=&quot;title_detail&quot;&gt;
&lt;div class=&quot;icon-name fa fa-truck pull-left&quot;&gt;&amp;nbsp;&lt;/div&gt;

&lt;div class=&quot;description&quot;&gt;
&lt;h4&gt;Free&lt;br /&gt;
Shipping&lt;/h4&gt;

&lt;p&gt;One order over $99&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;info&quot;&gt;Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.&lt;/div&gt;
";i:2;s:1504:"&lt;div class=&quot;title_detail&quot;&gt;
&lt;div class=&quot;icon-name fa fa-truck pull-left&quot;&gt;&amp;nbsp;&lt;/div&gt;

&lt;div class=&quot;description&quot;&gt;
&lt;h4&gt;Free&lt;br /&gt;
Shipping&lt;/h4&gt;

&lt;p&gt;One order over $99&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;info&quot;&gt;Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.&lt;/div&gt;
";}}i:2;a:4:{s:11:"select_icon";s:12:"fa-life-ring";s:5:"title";a:2:{i:1;s:24:"AMAZING CUSTOMER SERVICE";i:2;s:34:"خدمة العملاء مذهلة";}s:7:"caption";a:2:{i:1;s:166:"&lt;p&gt;Get Free Shipping on all orders over $75 and free returns to our UK returns centre! Items are dispatched from the US and will arrive in 5-8 days.&lt;/p&gt;
";i:2;s:1148:"&lt;p&gt;&lt;span id=&quot;result_box&quot; lang=&quot;ar&quot;&gt;&lt;span class=&quot;hps&quot;&gt;احصل على شحن&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;مجاني على جميع&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;أوامر&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;أكثر من دولار&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;75 و&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;عوائد&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;حرة في&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;المملكة المتحدة&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;لدينا&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;مركز العودة&lt;/span&gt;&lt;span&gt;!&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;وارسلت وحدات&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;من الولايات المتحدة&lt;/span&gt;&lt;span&gt;، وسوف&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;تصل&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;في 5-8&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;أيام&lt;/span&gt;&lt;span&gt;.&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;
";}s:6:"detail";a:2:{i:1;s:1506:"&lt;div class=&quot;title_detail&quot;&gt;
&lt;div class=&quot;icon-name fa fa-life-ring pull-left&quot;&gt;&amp;nbsp;&lt;/div&gt;

&lt;div class=&quot;description&quot;&gt;
&lt;h4&gt;AMAZING CUSTOMER SERVICE&lt;/h4&gt;

&lt;p&gt;One order over $99&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;info&quot;&gt;Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.&lt;/div&gt;
";i:2;s:1506:"&lt;div class=&quot;title_detail&quot;&gt;
&lt;div class=&quot;icon-name fa fa-life-ring pull-left&quot;&gt;&amp;nbsp;&lt;/div&gt;

&lt;div class=&quot;description&quot;&gt;
&lt;h4&gt;AMAZING CUSTOMER SERVICE&lt;/h4&gt;

&lt;p&gt;One order over $99&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;info&quot;&gt;Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.&lt;/div&gt;
";}}i:3;a:4:{s:11:"select_icon";s:11:"fa-smile-o ";s:5:"title";a:2:{i:1;s:24:"NO CUSTOMS OR DUTY FEES!";i:2;s:37:" رسوم جمركية أو واجب!";}s:7:"caption";a:2:{i:1;s:166:"&lt;p&gt;Get Free Shipping on all orders over $75 and free returns to our UK returns centre! Items are dispatched from the US and will arrive in 5-8 days.&lt;/p&gt;
";i:2;s:1148:"&lt;p&gt;&lt;span id=&quot;result_box&quot; lang=&quot;ar&quot;&gt;&lt;span class=&quot;hps&quot;&gt;احصل على شحن&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;مجاني على جميع&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;أوامر&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;أكثر من دولار&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;75 و&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;عوائد&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;حرة في&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;المملكة المتحدة&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;لدينا&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;مركز العودة&lt;/span&gt;&lt;span&gt;!&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;وارسلت وحدات&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;من الولايات المتحدة&lt;/span&gt;&lt;span&gt;، وسوف&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;تصل&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;في 5-8&lt;/span&gt; &lt;span class=&quot;hps&quot;&gt;أيام&lt;/span&gt;&lt;span&gt;.&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;
";}s:6:"detail";a:2:{i:1;s:1504:"&lt;div class=&quot;title_detail&quot;&gt;
&lt;div class=&quot;icon-name fa fa-smile-o pull-left&quot;&gt;&amp;nbsp;&lt;/div&gt;

&lt;div class=&quot;description&quot;&gt;
&lt;h4&gt;NO CUSTOMS OR DUTY FEES!&lt;/h4&gt;

&lt;p&gt;One order over $99&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;info&quot;&gt;Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.&lt;/div&gt;
";i:2;s:1506:"&lt;div class=&quot;title_detail&quot;&gt;
&lt;div class=&quot;icon-name fa fa-life-ring pull-left&quot;&gt;&amp;nbsp;&lt;/div&gt;

&lt;div class=&quot;description&quot;&gt;
&lt;h4&gt;AMAZING CUSTOMER SERVICE&lt;/h4&gt;

&lt;p&gt;One order over $99&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;info&quot;&gt;Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.&lt;/div&gt;
";}}}}}