a:4:{i:1;a:8:{s:12:"module_title";a:2:{i:1;s:8:"shipment";i:2;s:8:"شحنة";}s:11:"description";a:2:{i:1;s:1056:"&lt;ul class=&quot;media-list clearfix&quot;&gt;
	&lt;li class=&quot;media&quot;&gt;&lt;span class=&quot;pull-left fa fa-truck&quot;&gt;&amp;nbsp;&lt;/span&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h5&gt;&lt;a href=&quot;#&quot;&gt;Free shipping&lt;/a&gt;&lt;/h5&gt;
	&lt;em&gt;&lt;span&gt;One order over $99&lt;/span&gt;&lt;/em&gt;&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;media clearfix&quot;&gt;&lt;span class=&quot;pull-left fa fa-retweet&quot;&gt;&amp;nbsp;&lt;/span&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h5&gt;&lt;a href=&quot;#&quot;&gt;Free return&lt;/a&gt;&lt;/h5&gt;
	&lt;em&gt;&lt;span&gt;free 90 days return policy&lt;/span&gt;&lt;/em&gt;&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;media clearfix&quot;&gt;&lt;span class=&quot;pull-left fa fa-money&quot;&gt;&amp;nbsp;&lt;/span&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h5&gt;&lt;a href=&quot;#&quot;&gt;member discounts&lt;/a&gt;&lt;/h5&gt;
	&lt;em&gt;&lt;span&gt;free register&lt;/span&gt;&lt;/em&gt;&lt;/div&gt;
	&lt;/li&gt;
&lt;/ul&gt;
";i:2;s:1115:"&lt;ul class=&quot;media-list clearfix&quot;&gt;
	&lt;li class=&quot;media&quot;&gt;&lt;span class=&quot;pull-left fa fa-truck&quot;&gt;&amp;nbsp;&lt;/span&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h5&gt;&lt;a href=&quot;#&quot;&gt;الشحن مجانا&lt;/a&gt;&lt;/h5&gt;
	&lt;em&gt;&lt;span&gt;واحد أمر أكثر من 99 $&lt;/span&gt;&lt;/em&gt;&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;media clearfix&quot;&gt;&lt;span class=&quot;pull-left fa fa-retweet&quot;&gt;&amp;nbsp;&lt;/span&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h5&gt;&lt;a href=&quot;#&quot;&gt;العودة الحرة&lt;/a&gt;&lt;/h5&gt;
	&lt;em&gt;&lt;span&gt;حرة 90 يوما عودة السياسة&lt;/span&gt;&lt;/em&gt;&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;media clearfix&quot;&gt;&lt;span class=&quot;pull-left fa fa-money&quot;&gt;&amp;nbsp;&lt;/span&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h5&gt;&lt;a href=&quot;#&quot;&gt;خصومات عضو&lt;/a&gt;&lt;/h5&gt;
	&lt;em&gt;&lt;span&gt;سجل مجانا&lt;/span&gt;&lt;/em&gt;&lt;/div&gt;
	&lt;/li&gt;
&lt;/ul&gt;
";}s:10:"show_title";s:1:"1";s:9:"layout_id";s:5:"99999";s:8:"position";s:13:"footer_center";s:6:"status";s:1:"1";s:12:"module_class";s:0:"";s:10:"sort_order";s:1:"3";}i:2;a:8:{s:12:"module_title";a:2:{i:1;s:8:"About Us";i:2;s:11:"من نحن";}s:11:"description";a:2:{i:1;s:605:"&lt;address&gt;
&lt;p&gt;Address:&lt;span&gt;&amp;nbsp; Aliquam viverra magna ac enim pharetra cursus. Praesent quis ante dapibus tellus mollis dapibus ullamcorper sit amet erat. &lt;/span&gt;&lt;/p&gt;

&lt;p&gt;&lt;abbr title=&quot;Phone&quot;&gt;Phone:&lt;/abbr&gt;&lt;span&gt;&amp;nbsp; (123) 456-7890&lt;/span&gt;&lt;/p&gt;

&lt;p&gt;&lt;abbr title=&quot;Fax&quot;&gt;Fax:&lt;/abbr&gt;&lt;span&gt;&amp;nbsp; 11-222.333&lt;/span&gt;&lt;/p&gt;

&lt;p class=&quot;link-active&quot;&gt;Email:&amp;nbsp;&lt;a href=&quot;mailto:#&quot;&gt;pavothemes@gmail.com&lt;/a&gt;&lt;/p&gt;
&lt;/address&gt;
";i:2;s:649:"&lt;address&gt;
&lt;p&gt;العنوان:&lt;span&gt;&amp;nbsp; Aliquam viverra magna ac enim pharetra cursus. Praesent quis ante dapibus tellus mollis dapibus ullamcorper sit amet erat. &lt;/span&gt;&lt;/p&gt;

&lt;p&gt;&lt;abbr title=&quot;Phone&quot;&gt;الهاتف:&lt;/abbr&gt;&lt;span&gt;&amp;nbsp; (123) 456-7890&lt;/span&gt;&lt;/p&gt;

&lt;p&gt;&lt;abbr title=&quot;Fax&quot;&gt;فاكس:&lt;/abbr&gt;&lt;span&gt;&amp;nbsp; 11-222.333&lt;/span&gt;&lt;/p&gt;

&lt;p&gt;البريد الإلكتروني:&amp;nbsp;&lt;a class=&quot;add-mail&quot; href=&quot;mailto:#&quot;&gt;pavothemes@gmail.com&lt;/a&gt;&lt;/p&gt;
&lt;/address&gt;
";}s:10:"show_title";s:1:"1";s:9:"layout_id";s:5:"99999";s:8:"position";s:13:"footer_center";s:6:"status";s:1:"1";s:12:"module_class";s:0:"";s:10:"sort_order";s:1:"1";}i:3;a:8:{s:12:"module_title";a:2:{i:1;s:6:"Banner";i:2;s:8:"راية";}s:11:"description";a:2:{i:1;s:1426:"&lt;div class=&quot;row hidden-xs hidden-sm&quot;&gt;
&lt;div class=&quot;col-lg-4 col-md-4 col-sm-4&quot;&gt;
&lt;div class=&quot;banner-wrapper effect&quot;&gt;
&lt;div class=&quot;banner-meta&quot;&gt;
&lt;div class=&quot;banner-inner&quot;&gt;&lt;span&gt;About Us&lt;/span&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;a class=&quot;banner-image&quot; href=&quot;#&quot;&gt;&lt;img src=&quot;image/data/banner/banner1.jpg&quot; alt=&quot;img&quot;/&gt; &lt;/a&gt;&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;col-lg-4 col-md-4 col-sm-4&quot;&gt;
&lt;div class=&quot;banner-wrapper effect&quot;&gt;
&lt;div class=&quot;banner-meta&quot;&gt;
&lt;div class=&quot;banner-inner&quot;&gt;&lt;span&gt;weekly give away&lt;/span&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;a class=&quot;banner-image&quot; href=&quot;#&quot;&gt;&lt;img src=&quot;image/data/banner/banner2.jpg&quot; alt=&quot;img&quot;/&gt; &lt;/a&gt;&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;col-lg-4 col-md-4 col-sm-4&quot;&gt;
&lt;div class=&quot;banner-wrapper effect&quot;&gt;
&lt;div class=&quot;banner-meta&quot;&gt;
&lt;div class=&quot;banner-inner&quot;&gt;&lt;span&gt;Save up &lt;strong&gt;30%&lt;/strong&gt; with Vourcher&lt;/span&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;a class=&quot;banner-image&quot; href=&quot;#&quot;&gt;&lt;img src=&quot;image/data/banner/banner3.jpg&quot; alt=&quot;img&quot;/&gt; &lt;/a&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
";i:2;s:1330:"&lt;div class=&quot;row hidden-xs&quot;&gt;
&lt;div class=&quot;col-lg-4 col-md-4 col-sm-4&quot;&gt;
&lt;div class=&quot;banner-wrapper effect&quot;&gt;
&lt;div class=&quot;banner-meta&quot;&gt;
&lt;div class=&quot;banner-inner&quot;&gt;&lt;span&gt;About Us&lt;/span&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;a class=&quot;banner-image&quot; href=&quot;#&quot;&gt;&lt;img src=&quot;image/data/banner/banner1.jpg&quot; /&gt; &lt;/a&gt;&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;col-lg-4 col-md-4 col-sm-4&quot;&gt;
&lt;div class=&quot;banner-wrapper effect&quot;&gt;
&lt;div class=&quot;banner-meta&quot;&gt;
&lt;div class=&quot;banner-inner&quot;&gt;&lt;span&gt;weekly give away&lt;/span&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;a class=&quot;banner-image&quot; href=&quot;#&quot;&gt;&lt;img src=&quot;image/data/banner/banner2.jpg&quot; /&gt; &lt;/a&gt;&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;col-lg-4 col-md-4 col-sm-4&quot;&gt;
&lt;div class=&quot;banner-wrapper effect&quot;&gt;
&lt;div class=&quot;banner-meta&quot;&gt;
&lt;div class=&quot;banner-inner&quot;&gt;&lt;span&gt;Save up 30% with Vourcher&lt;/span&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;a class=&quot;banner-image&quot; href=&quot;#&quot;&gt;&lt;img src=&quot;image/data/banner/banner3.jpg&quot; /&gt; &lt;/a&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
";}s:10:"show_title";s:1:"1";s:9:"layout_id";s:1:"1";s:8:"position";s:8:"showcase";s:6:"status";s:1:"1";s:12:"module_class";s:19:"hidden-xs hidden-sm";s:10:"sort_order";s:1:"1";}i:4;a:8:{s:12:"module_title";a:2:{i:1;s:7:"Account";i:2;s:12:"الحساب";}s:11:"description";a:2:{i:1;s:674:"&lt;ul class=&quot;list-style&quot;&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/account&quot;&gt;My Account&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/order&quot;&gt;Order History&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/wishlist&quot;&gt;Wish List&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/newsletter&quot;&gt;Newsletter&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;?route=pavblog/blogs&quot;&gt;Blog&lt;/a&gt;&lt;/li&gt;
	&lt;li class=&quot;last&quot;&gt;&lt;a href=&quot;index.php?route=product/special&quot;&gt;Specials&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
";i:2;s:734:"&lt;ul class=&quot;list&quot;&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/account&quot;&gt;حسابي&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/order&quot;&gt;أجل التاريخ&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/wishlist&quot;&gt;قائمة المفضلة&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/newsletter&quot;&gt;النشرة الإخبارية&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;?route=pavblog/blogs&quot;&gt;بلوق&lt;/a&gt;&lt;/li&gt;
	&lt;li class=&quot;last&quot;&gt;&lt;a href=&quot;index.php?route=product/special&quot;&gt;العروض الخاصة&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
";}s:10:"show_title";s:1:"1";s:9:"layout_id";s:5:"99999";s:8:"position";s:13:"footer_center";s:6:"status";s:1:"1";s:12:"module_class";s:0:"";s:10:"sort_order";i:4;}}