<?php
// Heading
$_['heading_title']         = 'Báo cáo điểm thưởng của khách hàng';

// Column
$_['column_customer']       = 'Tên khách hàng';
$_['column_email']          = 'E-Mail';
$_['column_customer_group'] = 'Nhóm khách hàng';
$_['column_status']         = 'Trạng thái';
$_['column_points']         = 'Điểm thưởng';
$_['column_orders']         = 'Số đơn hàng';
$_['column_total']          = 'Tổng cộng';
$_['column_action']         = 'Thao tác';

// Entry
$_['entry_date_start']      = 'Ngày bắt đầu:';
$_['entry_date_end']        = 'Ngày kết thúc:';
?>