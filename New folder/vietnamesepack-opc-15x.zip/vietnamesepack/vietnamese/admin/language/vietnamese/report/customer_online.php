<?php
// Heading
$_['heading_title']     = 'Báo cáo khách hàng trực tuyến';

// Text 
$_['text_guest']        = 'Guest';
 
// Column
$_['column_ip']         = 'IP';
$_['column_customer']   = 'Khách hàng';
$_['column_url']        = 'Trang cuối cùng truy cập';
$_['column_referer']    = 'Referer';
$_['column_date_added'] = 'Lần click cuối';
$_['column_action']     = 'Thao tác';
?>