<?php
// Heading
$_['heading_title']  = 'Báo cáo sản phẩm được xem';

// Text
$_['text_success']   = 'Thành Công: Bạn đã thiết lập lại các báo cáo sản phẩm được xem!';

// Column
$_['column_name']    = 'Tên sản phẩm';
$_['column_model']   = 'Model';
$_['column_viewed']  = 'Đã xem';
$_['column_percent'] = 'Tỉ lệ';
?>