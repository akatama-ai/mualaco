<?php
// Heading
$_['heading_title']         = 'Báo cáo đơn hàng của khách hàng';

// Text
$_['text_all_status']       = 'Tất cả các trạng thái';

// Column
$_['column_customer']       = 'Tên khách hàng';
$_['column_email']          = 'E-Mail';
$_['column_customer_group'] = 'Nhóm khách hàng';
$_['column_status']         = 'Trạng thái';
$_['column_orders']         = 'Số đơn hàng';
$_['column_products']       = 'Số sản phẩm';
$_['column_total']          = 'Tổng cộng';
$_['column_action']         = 'Thao tác';

// Entry
$_['entry_date_start']      = 'Ngày bắt đầu:';
$_['entry_date_end']        = 'Ngày kết thúc:';
$_['entry_status']          = 'Trạng thái đơn hàng:';
?>