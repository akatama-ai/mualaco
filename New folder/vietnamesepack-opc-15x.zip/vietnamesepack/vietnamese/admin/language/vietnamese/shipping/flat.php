<?php
// Heading
$_['heading_title']    = 'Tỷ lệ cố định';

// Text
$_['text_shipping']    = 'Shipping';
$_['text_success']     = 'Thành Công: Bạn đã thay đổi flat rate shipping!';

// Entry
$_['entry_cost']       = 'Chi phí:';
$_['entry_tax_class']  = 'Tax Class:';
$_['entry_geo_zone']   = 'Vùng tính thuế';
$_['entry_status']     = 'Trạng thái:';
$_['entry_sort_order'] = 'Sắp xếp đơn hàng:';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền chỉnh sửa flat rate shipping!';
?>