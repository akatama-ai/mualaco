<?php
// Heading
$_['heading_title']    = 'Google Base';

// Text   
$_['text_feed']        = 'Nguồn cấp dữ liệu sản phẩm';
$_['text_success']     = 'Thành công: Bạn đã thay đổi nguồn cấp dữ liệu Google Base!';

// Entry
$_['entry_status']     = 'Tình trạng:';
$_['entry_data_feed']  = 'Dữ Liệu Url:';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền sửa đổi nguồn cấp dữ liệu Google Base!';
?>