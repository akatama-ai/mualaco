<?php
// header
$_['heading_title']  = 'Thiết lập lại mật khẩu của bạn';

// Text
$_['text_reset']     = 'Thiết lập lại mật khẩu của bạn!';
$_['text_password']  = 'Nhập mật khẩu mới mà bạn muốn sử dụng.';
$_['text_success']   = 'Thành công: mật khẩu của bạn đã được cập nhật thành công.';

// Entry
$_['entry_password'] = 'Mật khẩu:';
$_['entry_confirm']  = 'Xác nhận mật khẩu:';

// Error
$_['error_password'] = 'Mật khẩu phải có từ 5 đến 20 ký tự!';
$_['error_confirm']  = 'Mật khẩu và xác nhận mật khẩu không khớp!';
?>