<?php
// Heading
$_['heading_title']    = 'Lý do trở lại';

// Text
$_['text_success']     = 'Thành công: Bạn đã sửa đổi lý do trở lại!';

// Column
$_['column_name']      = 'Tên lý do trở lại';
$_['column_action']    = 'Thao tác';

// Entry
$_['entry_name']       = 'Tên lý do trở lại:';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền sửa đổi lý do trở lại!';
$_['error_name']       = 'Tên Quay Lý do trở lại phải có từ 3 đến 32 ký tự!';
$_['error_return']     = 'Cảnh báo: Điều này lý do trở lại không thể xóa được vì nó đang được giao cho %s sản phẩm trở lại !';
?>