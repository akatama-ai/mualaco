<?php
// Heading
$_['heading_title'] = 'Lịch sử lỗi';

// Text
$_['text_success']  = 'Thành công: Bạn đã xóa lịch sử lỗi!';
?>