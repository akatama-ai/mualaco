<?php
$_['text_credit']   = 'Cửa hàng tín dụng';
$_['text_order_id'] = 'Số đơn hàng ID: #%s';
?>