<?php
// Text
$_['text_subject']  = 'Bạn đã gửi phiếu quà tặng từ %s';
$_['text_greeting'] = 'Chúc mừng, Bạn nhận được phiếu Quà Tặng trị giá %s';
$_['text_from']     = 'Phiếu quà tặng được gửi đến bạn bởi %s';
$_['text_message']  = 'Với lời nhắn';
$_['text_redeem']   = 'Để sử dụng Phiếu Quà Tặng, ghi lại mã sau <b>%s</b> sau đó bấm vào đường link bên dưới và thanh toán sản phẩm bạn muốn sử dụng phiếu quà tặng. Bạn cũng có thể nhập mã Phiếu Quà Tặng trong trang giỏ hàng trước khi thanh toán.';
$_['text_footer']   = 'Vui lòng trả lời thư này nếu bạn có bất kì câu hỏi nào.';
?>