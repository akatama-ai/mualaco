<?php
// Text
$_['text_title']  = 'Citylink';
$_['text_weight'] = 'Trọng lượng:';
?>