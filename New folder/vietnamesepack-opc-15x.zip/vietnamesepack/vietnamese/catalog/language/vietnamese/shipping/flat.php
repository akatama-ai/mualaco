<?php
// Text
$_['text_title']       = 'Phí cố định';
$_['text_description'] = 'Phí vận chuyển cố định';
?>