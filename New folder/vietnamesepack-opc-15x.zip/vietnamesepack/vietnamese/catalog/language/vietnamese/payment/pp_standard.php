<?php
// Text
$_['text_title']    = 'PayPal';
$_['text_reason'] 	= 'Lý do';
$_['text_testmode']	= 'Cảnh báo: Cổng thanh toán đang trong chế độ \'Sandbox Mode\'. Tài khoản của bạn sẽ không được trả.';
$_['text_total']	= 'Vận chuyển, Xử lý, Giảm giá và Thuế';
?>