<?php
// Text
$_['text_title']           = 'Thẻ Tín Dụng / Thẻ Ghi Nợ (SagePay)';
$_['text_credit_card']     = 'Chi tiết Credit Card';
$_['text_wait']            = 'Vui lòng chờ!';

// Entry
$_['entry_cc_owner']       = 'Chủ thẻ:';
$_['entry_cc_number']      = 'Số thẻ:';
$_['entry_cc_expire_date'] = 'Thẻ hết hạn ngày:';
$_['entry_cc_cvv2']        = 'Mã thẻ an ninh (CVV2):';
?>