<?php
// Text
$_['text_title'] = 'Thẻ Tín Dụng / Thẻ Ghi Nợ (VeriSign)';
?>