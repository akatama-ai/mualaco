<?php
$_['heading_title']     = 'Tags';

$_['text_notags']       = 'No tags available';
$_['text_href_title']   = 'items tagged with';
?>