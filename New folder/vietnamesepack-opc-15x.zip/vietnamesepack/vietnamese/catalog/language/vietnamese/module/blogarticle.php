<?php
$_['heading_title']     = 'Recent Articles';
?>