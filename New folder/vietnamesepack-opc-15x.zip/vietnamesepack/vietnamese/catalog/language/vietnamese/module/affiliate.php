﻿<?php
// Heading 
$_['heading_title']    = 'Đại lý';

// Text
$_['text_register']    = 'Đăng kí';
$_['text_login']       = 'Đăng nhập';
$_['text_logout']      = 'Đăng xuất';
$_['text_forgotten']   = 'Quên mật khẩu';
$_['text_account']     = 'Tài khoản của tôi';
$_['text_edit']        = 'Thay đổi tài khoản';
$_['text_password']    = 'Mật khẩu';
$_['text_payment']     = 'Tùy chọn thanh toán';
$_['text_tracking']    = 'Theo dõi của đại lý';
$_['text_transaction'] = 'Giao dịch';
?>
