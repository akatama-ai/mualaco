<?php
// Heading 
$_['heading_title'] = 'Khuyến mãi';

// Text
$_['text_reviews']  = 'Dựa trên %s đánh giá.'; 
?>