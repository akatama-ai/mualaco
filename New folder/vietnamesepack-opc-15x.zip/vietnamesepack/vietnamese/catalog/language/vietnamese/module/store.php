<?php
// Heading 
$_['heading_title'] = 'Chọn gian hàng';

// Text
$_['text_default']  = 'Mặc định';
$_['text_store']    = 'Vui lòng chọn gian hàng bạn muốn xem.';
?>