<?php

$_['text_item'] = "item";
$_['text_items'] = "items";
$_['heading_title'] = "Category Accessories";
$_['view_all'] = "View all";

?>