<?php
// Heading 
$_['heading_title'] = 'آخر';

$_['all_product'] = 'جميع المنتجات';


// Text
$_['text_latest']  = 'آخر'; 
$_['text_mostviewed']  = 'الأكثر تصفحا'; 
$_['text_featured']  = 'متميز'; 
$_['text_bestseller']  = 'أفضل بائع'; 
$_['text_special']  = 'خاص';
?>