<?php 

$_['text_watch_video_testimonial'] = 'وانتهاءً وصل. ولم ٣٠';
$_['text_testimonial'] = ' ثم يذكر تكتيكاً';
$_['text_testimonial_title'] = 'ثم يذكر تكتيكاً';

?>