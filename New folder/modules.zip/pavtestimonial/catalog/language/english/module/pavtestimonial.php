<?php 

$_['text_watch_video_testimonial'] = 'Watch Video';
$_['text_testimonial'] = 'What Peopel Say';
$_['text_testimonial_title'] = 'Testimonial';
?>